 #!/bin/bash
 python3 /home/user/timp/lab3/blog/manage.py runserver localhost:8003
