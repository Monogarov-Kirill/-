 #!/bin/bash
 python3 /home/user/timp/lab6/blog/manage.py runserver localhost:8006
