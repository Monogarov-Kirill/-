from django.apps import AppConfig


class FlatpagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'flatpages'
