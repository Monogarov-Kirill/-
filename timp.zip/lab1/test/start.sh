 #!/bin/bash

 python3 /home/user/timp/lab1/test/manage.py runserver localhost:8001
